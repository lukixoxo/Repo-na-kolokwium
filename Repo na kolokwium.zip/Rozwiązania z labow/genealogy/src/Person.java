import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.*;

public class Person {

    private String name;
    private int birthYear;
    private Optional<Integer> deathYear;

    private Optional<Person> mother;
    private Optional<Person> father;

    public Person(String name, int birthYear) {
        this.name = name;
        this.birthYear = birthYear;
        this.deathYear = Optional.empty();
        this.mother = Optional.empty();
        this.father = Optional.empty();
    }

    public Person(String name, int birthYear, int deathYear) {
        this(name, birthYear);
        this.deathYear = Optional.of(deathYear);
    }



    public static List<Person> fromCsvFile(String filePath) throws IOException {
        return Files.lines(Path.of(filePath))
                .skip(1)
                .map(line -> line.split(","))
                .map(parts -> {
                    String name = parts[0];
                    int birthYear = Integer.parseInt(parts[1]);

                    return (parts.length > 2 && !parts[2].isBlank())
                            ? new Person(name, birthYear, Integer.parseInt(parts[2]))
                            : new Person(name, birthYear);
                })
                .toList();
    }
    public void adopt(Person parent) {
        Optional<Person> p = Optional.ofNullable(parent);

        if (mother.isEmpty()) {
            mother = p;
        } else if (father.isEmpty()) {
            father = p;
        }
    }

    public String getName() { return name; }
    public int getBirthYear() { return birthYear; }
    public Optional<Integer> getDeathYear() { return deathYear; }

    public Optional<Person> getMother() { return mother; }
    public Optional<Person> getFather() { return father; }

    public void setMother(Person mother) {
        this.mother = Optional.ofNullable(mother);
    }

    public void setFather(Person father) {
        this.father = Optional.ofNullable(father);
    }

    public boolean isAlive() {
        return deathYear.isEmpty();
    }

    public int getAge() {
        int end = deathYear.orElse(Calendar.getInstance().get(Calendar.YEAR));
        return end - birthYear;
    }

    // ===== Zadanie 2 =====
    public String toPlantUML() {
        StringBuilder sb = new StringBuilder("@startuml\n");

        sb.append("object \"" + name + "\" as me\n");

        mother.ifPresent(m -> {
            sb.append("object \"" + m.name + "\" as mother\n");
            sb.append("me --> mother\n");
        });

        father.ifPresent(f -> {
            sb.append("object \"" + f.name + "\" as father\n");
            sb.append("me --> father\n");
        });

        sb.append("@enduml");
        return sb.toString();
    }

    // ===== Zadanie 3 =====
    public static String toPlantUML(List<Person> people) {
        StringBuilder sb = new StringBuilder("@startuml\n");

        people.forEach(p ->
                sb.append("object \"" + p.name + "\" as " + p.name + "\n")
        );

        people.forEach(p -> {
            p.mother.ifPresent(m ->
                    sb.append(p.name + " --> " + m.name + "\n")
            );
            p.father.ifPresent(f ->
                    sb.append(p.name + " --> " + f.name + "\n")
            );
        });

        sb.append("@enduml");
        return sb.toString();
    }

    // ===== Zadanie 4 =====
    public static List<Person> filterByName(List<Person> people, String substring) {
        return people.stream()
                .filter(p -> p.name.contains(substring))
                .toList();
    }

    // ===== Zadanie 5 =====
    public static List<Person> sortByBirthYear(List<Person> people) {
        return people.stream()
                .sorted(Comparator.comparingInt(Person::getBirthYear))
                .toList();
    }

    // ===== Zadanie 6 =====
    public static List<Person> deadSortedByLifespan(List<Person> people) {
        return people.stream()
                .filter(p -> p.getDeathYear().isPresent())
                .sorted(Comparator.comparingInt(Person::getAge).reversed())
                .toList();
    }

    // ===== Zadanie 7 =====
    public static Optional<Person> oldestAlive(List<Person> people) {
        return people.stream()
                .filter(Person::isAlive)
                .max(Comparator.comparingInt(Person::getAge));
    }

    // ===== Zadanie 8 =====
    public String toPlantUML(Function<String, String> postProcess) {
        StringBuilder sb = new StringBuilder("@startuml\n");

        sb.append(postProcess.apply("object \"" + name + "\" as me\n"));

        mother.ifPresent(m -> {
            sb.append(postProcess.apply("object \"" + m.name + "\" as mother\n"));
            sb.append("me --> mother\n");
        });

        father.ifPresent(f -> {
            sb.append(postProcess.apply("object \"" + f.name + "\" as father\n"));
            sb.append("me --> father\n");
        });

        sb.append("@enduml");
        return sb.toString();
    }

    // ===== Zadanie 9 =====
    public String toPlantUML(Function<String, String> postProcess,
                             Predicate<Person> condition) {

        StringBuilder sb = new StringBuilder("@startuml\n");

        Function<Person, String> line = p ->
                "object \"" + p.name + "\" as " + p.name + "\n";

        Function<Person, String> processed = p ->
                condition.test(p)
                        ? postProcess.apply(line.apply(p))
                        : line.apply(p);

        sb.append(processed.apply(this));

        mother.ifPresent(m -> {
            sb.append(processed.apply(m));
            sb.append(name + " --> " + m.name + "\n");
        });

        father.ifPresent(f -> {
            sb.append(processed.apply(f));
            sb.append(name + " --> " + f.name + "\n");
        });

        sb.append("@enduml");
        return sb.toString();
    }
}