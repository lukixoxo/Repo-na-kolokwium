import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class PlantUMLRunner {

    public static void saveToFile(String uml, String outputDir, String fileName)
            throws IOException {

        Path file = Path.of(outputDir, fileName + ".puml");
        Files.writeString(file, uml);
    }
}