import java.util.*;
import java.util.stream.*;

public class Family {

    private final Map<String, List<Person>> people = new HashMap<>();

    public void add(Person... persons) {
        Arrays.stream(persons)
                .forEach(p -> people
                        .computeIfAbsent(p.getName(), k -> new ArrayList<>())
                        .add(p)
                );

        people.values().forEach(list ->
                list.sort(Comparator.comparingInt(Person::getBirthYear))
        );
    }

    public List<Person> get(String key) {
        return Optional.ofNullable(people.get(key))
                .orElse(List.of());
    }
}